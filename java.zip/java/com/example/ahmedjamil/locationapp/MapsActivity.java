package com.example.ahmedjamil.locationapp;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.CountDownTimer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.UUID;

import static android.bluetooth.BluetoothDevice.BOND_BONDED;
import static android.bluetooth.BluetoothDevice.BOND_NONE;


public class MapsActivity extends FragmentActivity implements AdapterView.OnItemClickListener, OnMapReadyCallback {

    private GoogleMap mMap;
    Marker marker1, marker2;
    LatLng latlngModule1, latlngModule2;
    Button b1,b2,b3;
    ImageButton ib;

    int choice = 1;
    TextView textview2, textview4, textview5, textview6, textview7;
    String slat1,slong1,slat2,slong2, sdistance;

    static BluetoothAdapter mBluetoothAdapter;
    static BluetoothDevice mBluetoothDevice;
    DeviceListAdapter mDeviceListAdapter;
    BluetoothSocket mBluetoothSocket;
    private final UUID MY_UUID_INSECURE =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String TAG = "Bluetooth_Activity";
    public  int a;
    private ListView NewDevices_List;
    private ArrayAdapter<String> adapter = null;
    int opened  = 1;
    public ArrayList<BluetoothDevice> mBTDevices;
    public static String deviceNamee;

    double Lat1, Lat2, Long1, Long2;


    InputStream inputStream;
    String recieved;

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "onReceive: ACTION FOUND.");

            if (action.equals(BluetoothDevice.ACTION_FOUND)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                mBTDevices.add(device);
                Log.d(TAG, "onReceive: " + device.getName() + ": " + device.getAddress());
                mDeviceListAdapter = new DeviceListAdapter(context, R.layout.device_adapter_view, mBTDevices);
                NewDevices_List.setAdapter(mDeviceListAdapter);
            }

        }
    };

    private BroadcastReceiver mBroadcastReceiver2 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();

            if(action.equals(BluetoothDevice.ACTION_BOND_STATE_CHANGED)){
                BluetoothDevice mDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                if (mDevice.getBondState()== BluetoothDevice.BOND_BONDED){
                    Log.d("BT", "Paired");
                }

                if (mDevice.getBondState()== BluetoothDevice.BOND_BONDING){
                    Log.d("BT", "Pairing");
                }

                if (mDevice.getBondState()== BluetoothDevice.BOND_NONE){
                    Log.d("BT", "Not Paired");
                }
            }
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        final int Result = 1;

        if (requestCode == Result) {
            if (resultCode == RESULT_OK) {
                SearchUnpairedDevice();

            }

            else if (resultCode != RESULT_OK) {
                finish();
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        NewDevices_List = (ListView) findViewById(R.id.ListDevices);
        mBTDevices = new ArrayList<>();

        NewDevices_List.setOnItemClickListener(MapsActivity.this);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();


        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(mBroadcastReceiver2,filter);

        if (mBluetoothAdapter.isEnabled()) {
            Log.d("Msg", "Connected Already");
            SearchUnpairedDevice();

        }

        else if (!mBluetoothAdapter.isEnabled()) {

            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, final View view, final int i, long l) {
        mBluetoothAdapter.cancelDiscovery();
        Log.d("BT", "You tapped on a Device");
        deviceNamee = mBTDevices.get(i).getName();
        String deviceAddress = mBTDevices.get(i).getAddress();
        mBluetoothDevice = mBTDevices.get(i);
        try {
            mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(MY_UUID_INSECURE);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d("Connected", deviceNamee);
        a = i;
        mBTDevices.get(i).createBond();

        new CountDownTimer(50000,100){
            @Override
            public void onTick (long millisUntilFinished) {
                if (mBTDevices.get(i).getBondState() == BOND_BONDED && opened==1) { Map(); }
            }

            public void onFinish() {
                if (mBTDevices.get(i).getBondState() == BOND_NONE) { }
            }
        }.start();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.moveCamera(CameraUpdateFactory.zoomTo(15));
        mBluetoothAdapter.cancelDiscovery();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        mBluetoothAdapter.cancelDiscovery();


        try {
            if (mBluetoothAdapter.cancelDiscovery()) {
//                mBluetoothSocket = mBluetoothDevice.createInsecureRfcommSocketToServiceRecord(MY_UUID_INSECURE);
               try{
                   Method m = mBluetoothDevice.getClass().getMethod("createInsecureRfcommSocketToServiceRecord",new Class[] {UUID.class});
                   mBluetoothSocket = (BluetoothSocket) m.invoke(mBluetoothDevice,MY_UUID_INSECURE);
               }
               catch (Exception e){
                   Log.e("Socket" , "Could Not be created" );
               }

                mBluetoothSocket.connect();

            }

            if (!mBluetoothSocket.isConnected()) {
                Log.d("Socket", "Not Connected");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        if (mBluetoothSocket.isConnected()) {
            Log.d("Socket", "Connected");
            try {
                inputStream
 = mBluetoothSocket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            new CountDownTimer(86400000, 1000) {


                @Override
                public void onTick(long millisUntilFinished) {

                    mMap.clear();


                    getLatLong();
                    Log.d("GetLatLong", "Called");

                    double distance = 1000 * Haversine.distance(Lat1, Long1,
                            Lat2, Long2);

                    latlngModule1 = new LatLng(Lat1, Long1);
                    latlngModule2 = new LatLng(Lat2, Long2);

                    marker1 = mMap.addMarker(new MarkerOptions().position(latlngModule1).title("Module1")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
                    marker2 = mMap.addMarker(new MarkerOptions().position(latlngModule2).title("Module2")
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)));

                    marker1.isVisible();
                    marker2.isVisible();
                    camview();

                    DecimalFormat numberFormat = new DecimalFormat("#.0000000");
                    DecimalFormat numberFormat2 = new DecimalFormat("#.0");
                    slat1 = numberFormat.format(Lat1);
                    slong1 = numberFormat.format(Long1);
                    slat2 = numberFormat.format(Lat2);
                    slong2 = numberFormat.format(Long2);
                    sdistance = numberFormat2.format(distance);

                    textview2.setText(slat1);
                    textview5.setText(slong1);
                    textview4.setText(slat2);
                    textview6.setText(slong2);

                    textview7.setText(sdistance);
                }

                public void onFinish() {
                }
            }.start();

        }
    }


    private void SearchUnpairedDevice (){

        mBluetoothAdapter.cancelDiscovery();
        Log.d(TAG, "Discovery Canceled.");

        int MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION = 1;
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                MY_PERMISSIONS_REQUEST_ACCESS_COARSE_LOCATION);
        mBluetoothAdapter.startDiscovery();

        Log.d(TAG, "Discovery Started.");

        IntentFilter discoverDeviceIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);

        registerReceiver(mBroadcastReceiver, discoverDeviceIntent);

    }

    public void Map()
    {
        unregisterReceiver(mBroadcastReceiver);
        unregisterReceiver(mBroadcastReceiver2);
        opened = 0;
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        textview2 = (TextView) findViewById(R.id.textView2);
        textview4 = (TextView) findViewById(R.id.textView4);
        textview5 = (TextView) findViewById(R.id.textView5);
        textview6 = (TextView) findViewById(R.id.textView6);
        textview7 = (TextView) findViewById(R.id.textView7);

        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        ib = findViewById(R.id.imageButton);
        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ choice = 1; }
        });

        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                choice = 2; }
        });

        b3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ choice = 3; }
        });

        ib.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){  SmsManager manager = SmsManager.getDefault();
                manager.sendTextMessage("+923075694733", null , editable.toString(), null , null );}
        });


    }

    public void camview ()
    {
        if (choice == 1)
        { mMap.moveCamera(CameraUpdateFactory.newLatLng(latlngModule1));
            marker2.showInfoWindow();}
        if (choice == 2)
        {mMap.moveCamera(CameraUpdateFactory.newLatLng(latlngModule2));
            marker1.showInfoWindow();}
        if (choice == 3)
        {  mMap.stopAnimation();}
    }

    public void getLatLong()
    {
        byte[] buffer = new byte[1024];
        int bytes;
        try {
            bytes = inputStream.read(buffer);

            ByteArrayInputStream input = new ByteArrayInputStream(buffer);

            recieved = new String(buffer);

            String[] values = recieved.split("\n");
            slat1 = values[0];
            slat2 = values[1];
            slong1 = values[2];
            slong2 = values[3];
            if (slat1 != null && slat2!= null && slong1!= null && slong2!= null) {
                Lat1 = (Double.parseDouble(slat1))/1000000;

                Lat2 = (Double.parseDouble(slat2))/1000000;
                if (Lat2 < 0) {
                    Lat2 = Lat2 + 180;
                }
                if (Lat2 >= 0) {
                    Lat2 = Lat2 - 180;
                }

                Long1 = (Double.parseDouble(slong1))/1000000;
                if (Long1 < 0) {
                    Long1 = Long1 + 360;
                }
                if (Long1 >= 0) {
                    Long1 = Long1 - 360;
                }

                Long2 = (Double.parseDouble(slong2))/1000000;
                if (Long2 < 0) {
                    Long2 = Long2 + 550;
                }
                if (Long2 >= 0) {
                    Long2 = Long2 - 550;
                }
            }
            if (slat1 == null && slat2== null && slong1== null && slong2== null) {
            Log.d ("String" , "IS EMPTY");
            }

                Log.d("String", "Written");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
